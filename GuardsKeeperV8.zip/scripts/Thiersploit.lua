loadstring(game:GetObjects("rbxassetid://418957341")[1].Source)()

-- Dex v3